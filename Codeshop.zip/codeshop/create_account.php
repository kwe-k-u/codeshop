<?php
require(dirname(__FILE__).'../controllers/user_controller.php');


if(isset($_POST['developer'])){
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['psw'];
    $cpassword = $_POST['psw2'];

    if($password !== $cpassword){
        header('Location: index.php');
    }
    $npass = password_hash($password, PASSWORD_DEFAULT);

    if(add_user_controller($username, $email, $npass)!== true){
        header('Location: index.php');
    }
    header('Location: marketplace.php');

}

if(isset($_POST['buyer'])){
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['psw'];
    $cpassword = $_POST['psw2'];

    if($password !== $cpassword){
        header('Location: index.php');
    }
    $npass = password_hash($password, PASSWORD_DEFAULT);

    if(add_Customer_controller($username, $email, $npass)!== true){
        header('Location: index.php');
    }
    header('Location: marketplace.php');

}

?>