<?php

define('SERVER', 'localhost');
define('USER', 'root');
define('DATABASE', 'code_shop');
define('PASSWORD', '');
?>
