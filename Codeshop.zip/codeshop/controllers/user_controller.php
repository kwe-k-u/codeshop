<?php

require(dirname(__FILE__).'/../classes/user_class.php');

function add_Customer_controller($name, $email, $password){
    $Customer_instance = new Customer();
    return $Customer_instance->add_Customer($name, $email, $password);

}

function delete_Customer_controller($id){
    $Customer_instance = new Customer();
    return $Customer_instance->delete_Customer($id);

}

function update_Customer_controller($id, $name, $email, $password){
    $buyer_instance = new Customer();
    return $Customer_instance->update_buyer($id, $name, $email, $password);

}

function select_all_Customer_controller(){
    $buyer_instance = new Customer();
    return $Customer_instance ->select_all_Customer();

}

function select_one_Customer_controller($id){
    $Customer_instance = new Customer();
    return $Customer_instance->select_one_Customer($id);

}

function login_Customer_controller($email){
    $Customer_instance = new Customer();
    return $Customer_instance->login_Customer($email);

}


?>
